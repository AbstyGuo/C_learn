//
//  main.c
//  结构体作业
//
//  Created by qianfeng on 15-10-21.
//  Copyright (c) 2015年 student. All rights reserved.
//

#include <stdio.h>
void inputStudentInfo(struct student * stus,int length)
{
    int i;
    for (i=0; i<length; i++) {
        scanf("%s%d",stus[i].name,stus[i].age);
    }
    
}
void sort(struct student * stus,int length)
{
    
}
void printStudentInfo(struct student * stus,int length)
{
    
}
struct student
{
    char name[30];
    int age;
}b[30];
int main(int argc, const char * argv[])
{
    inputStudentInfo(b, 30);
    
    return 0;
}

