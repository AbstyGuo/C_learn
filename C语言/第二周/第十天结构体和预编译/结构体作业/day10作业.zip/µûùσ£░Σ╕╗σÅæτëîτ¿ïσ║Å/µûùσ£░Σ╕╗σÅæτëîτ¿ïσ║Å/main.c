//
//  main.c
//  斗地主发牌程序
//
//  Created by qianfeng on 15-10-22.
//  Copyright (c) 2015年 student. All rights reserved.
//

#include <stdio.h>
enum huase{
    heart,
    leaf,
    squear,
    club
};
struct puke{
    int huase;
    char shuzi;
}player[3][17],last3[3];


int main(int argc, const char * argv[])
{

    // insert code here...
    printf("Hello, World!\n");
    return 0;
}

