//
//  main.c
//  mystrstr
//
//  Created by qianfeng on 15-10-21.
//  Copyright (c) 2015年 student. All rights reserved.
//

#include <stdio.h>
#include <string.h>
char * mystrstr(char * a,char * b)
{
    char *p=a;
    int i,j=1;
    for (i=0; i<strlen(a); i++)
    {
        if(*p++==*b)
        {  while ((*p++=*b++))
            {
                j++;
            }
            if (j==strlen(b))
            {
                return p-j;
            }
        }
    }
    return p;
}
int main(int argc, const char * argv[])
{
    char a[100]={},b[10]={};
    scanf("%s%s",a,b);
    printf("%s\n",mystrstr(a, b));
    
    return 0;
}

