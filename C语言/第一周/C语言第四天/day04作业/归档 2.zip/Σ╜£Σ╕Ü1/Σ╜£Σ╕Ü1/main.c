//
//  main.c
//  作业1
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // 输入一个时间，输出这个时间之后一秒的时间
    int h,m,s;
    scanf("%d:%d:%d",&h,&m,&s);
    if (s+1<60)
        printf("%d:%d:%d\n",h,m,s+1);
    else if (m+1<60)
        printf("%d:%d:%d\n",h,m+1,0);
    else if (h+1<24)
        printf("%d:%d:%d\n",h+1,0,0);
    else
         printf("%d:%d:%d\n",0,0,0);
    return 0;
}
