//
//  main.c
//  作业3
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
//    输入一个字母，判断这个字母表示星期几，如果一个字母不能表示，再输入一个字母，输出星期几。
//    
//    M   Monday
//    T		Tuesday
//    W	wednesday
//    T		Thursday
//    F	   Friday
//    S		saturday
//    S		sunday
    char a,b;
    scanf("%c",&a);
    if (a>'Z') {
        a-=32;
    }
    switch (a) {
        case 'M':
            printf("Monday\n");
            break;
        case 'T':
        {
            printf("please input other number\n");
            scanf("\n%c",&b);
            switch (b){
                case 'u':
                    printf("Tuesday\n");
                    break;
                case 'U':
                    printf("Tuesday\n");
                    break;
                case 'h':
                    printf("Thursday\n");
                    break;
                case 'H':
                    printf("Thursday\n");
                    break;
                default:
                    break;
            }break;
        }
        case 'W':
            printf("Wednesday\n");
            break;
        case 'F':
            printf("Friday\n");
            break;
        case 'S':
        {
            printf("please input another number\n");
            scanf("\n%c",&b);
            switch (b){
                case 'a':
                    printf("Saturday\n");break;
                case 'A':
                    printf("Saturday\n");break;
                case 'u':
                    printf("Sunday\n");break;
                case 'U':
                    printf("Sunday\n");break;
                default:
                    break;
            }break;
        }
        default:
            break;
    }

    return 0;
}
