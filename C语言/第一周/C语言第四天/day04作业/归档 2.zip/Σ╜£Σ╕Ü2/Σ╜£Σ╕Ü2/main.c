//
//  main.c
//  作业2
//
//  Created by qianfeng on 15/10/13.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    /*2.编写程序,输入一个成绩(0-100);
    如果成绩是 0-59  显示"D";
    如果成绩是 60-69显示"C";
    如果成绩是 70-89显示"B";
    如果成绩是 90-100 显示 "A";*/
    int a;
    scanf("%d",&a);
    a/=10;
    switch (a) {
        case 1:
            printf("D\n");
            break;
        case 2:
            printf("D\n");
            break;
        case 3:
            printf("D\n");
            break;
        case 4:
            printf("D\n");
            break;
        case 5:
            printf("D\n");
            break;
        case 6:
            printf("C\n");
            break;
        case 7:
            printf("B\n");
            break;
        case 8:
            printf("B\n");
            break;
        case 9:
            printf("A\n");
            break;
        case 10:
            printf("A\n");
            break;
        default:
            break;
    }
    
    return 0;
}
